import ProfileCard from './ProfileCard';
import './index.css';

export default function App() {
  const profiles = [
    {
      image:
        'https://upload.wikimedia.org/wikipedia/commons/9/95/The_White_House_-_54409525537_%28cropped%29.jpg',
      name: 'Elon Musk',
      title: 'Entrepreneur',
      bio: 'CEO of Tesla and SpaceX, known for innovation in tech and space.',
      facebook: '#',
      instagram: 'https://www.instagram.com/elonmusk/',
      twitter: 'https://x.com/elonmusk',
    },
    {
      image:
        'https://upload.wikimedia.org/wikipedia/commons/7/7a/LeBron_James_%2851959977144%29_%28cropped2%29.jpg',
      name: 'LeBron James',
      title: 'NBA Player',
      bio: 'One of the greatest basketball players in history.',
      facebook: 'https://www.facebook.com/LeBron/',
      instagram: 'https://www.instagram.com/kingjames/',
      twitter: 'https://x.com/KingJames',
    },
    {
      image:
        'https://upload.wikimedia.org/wikipedia/commons/b/b1/Taylor_Swift_at_the_2023_MTV_Video_Music_Awards_%283%29.png',
      name: 'Taylor Swift',
      title: 'Musician',
      bio: 'Award-winning global pop and country artist.',
      facebook: 'https://www.facebook.com/TaylorSwift/',
      instagram: 'https://www.instagram.com/taylorswift/?hl=en',
      twitter: 'https://x.com/taylorswift13',
    },
  ];

  return (
    <div className="container">
      {profiles.map((profile, index) => (
        <ProfileCard key={index} {...profile} />
      ))}
    </div>
  );
}
