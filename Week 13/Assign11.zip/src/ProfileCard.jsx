import "./App.css";

function ProfileCard({ image, name, title, bio, facebook, instagram, twitter }) {
  return (
    <div className="card">
      <img src={image} alt={name} className="card-img" />
      <h2>{name}</h2>
      <h4>{title}</h4>
      <p>{bio}</p>

      <div className="buttons">
        <a href={facebook} target="_blank">
          <button className="fb">Facebook</button>
        </a>
        <a href={instagram} target="_blank">
          <button className="ig">Instagram</button>
        </a>
        <a href={twitter} target="_blank">
          <button className="tw">Twitter</button>
        </a>
      </div>
    </div>
  );
}

export default ProfileCard;